
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cosmostatic.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.cosmostatic.block.ParticleacceleratorBlock;
import net.mcreator.cosmostatic.block.MoonWoodBlock;
import net.mcreator.cosmostatic.block.MoonStairsBlock;
import net.mcreator.cosmostatic.block.MoonSlabBlock;
import net.mcreator.cosmostatic.block.MoonPressurePlateBlock;
import net.mcreator.cosmostatic.block.MoonPlanksBlock;
import net.mcreator.cosmostatic.block.MoonLogBlock;
import net.mcreator.cosmostatic.block.MoonLeavesBlock;
import net.mcreator.cosmostatic.block.MoonFenceGateBlock;
import net.mcreator.cosmostatic.block.MoonFenceBlock;
import net.mcreator.cosmostatic.block.MoonButtonBlock;
import net.mcreator.cosmostatic.block.MeteoricironBlock;
import net.mcreator.cosmostatic.block.DarkmatterblockBlock;
import net.mcreator.cosmostatic.CosmostaticMod;

public class CosmostaticModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CosmostaticMod.MODID);
	public static final RegistryObject<Block> DARKMATTERBLOCK = REGISTRY.register("darkmatterblock", () -> new DarkmatterblockBlock());
	public static final RegistryObject<Block> TRANSDUCER = REGISTRY.register("transducer", () -> new ParticleacceleratorBlock());
	public static final RegistryObject<Block> METEORICIRON = REGISTRY.register("meteoriciron", () -> new MeteoricironBlock());
	public static final RegistryObject<Block> MOON_WOOD = REGISTRY.register("moon_wood", () -> new MoonWoodBlock());
	public static final RegistryObject<Block> MOON_LOG = REGISTRY.register("moon_log", () -> new MoonLogBlock());
	public static final RegistryObject<Block> MOON_PLANKS = REGISTRY.register("moon_planks", () -> new MoonPlanksBlock());
	public static final RegistryObject<Block> MOON_LEAVES = REGISTRY.register("moon_leaves", () -> new MoonLeavesBlock());
	public static final RegistryObject<Block> MOON_STAIRS = REGISTRY.register("moon_stairs", () -> new MoonStairsBlock());
	public static final RegistryObject<Block> MOON_SLAB = REGISTRY.register("moon_slab", () -> new MoonSlabBlock());
	public static final RegistryObject<Block> MOON_FENCE = REGISTRY.register("moon_fence", () -> new MoonFenceBlock());
	public static final RegistryObject<Block> MOON_FENCE_GATE = REGISTRY.register("moon_fence_gate", () -> new MoonFenceGateBlock());
	public static final RegistryObject<Block> MOON_PRESSURE_PLATE = REGISTRY.register("moon_pressure_plate", () -> new MoonPressurePlateBlock());
	public static final RegistryObject<Block> MOON_BUTTON = REGISTRY.register("moon_button", () -> new MoonButtonBlock());
}
